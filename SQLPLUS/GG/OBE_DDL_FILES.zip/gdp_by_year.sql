insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (130, 2005, 113.244686862651);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (131, 2005, 41.7582078780814);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (132, 2005, 10.5489898511084);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (133, 2005, 0.875182106443613);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (134, 2005, 7.47280345610212);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (135, 2005, 22.8612324644273);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (136, 2005, 830.698976356336);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (137, 2005, 702.331365305546);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (138, 2005, 99.898724487446);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (139, 2005, 28.4688865633436);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (140, 2005, 2.95119613385189);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (141, 2005, 6.57903957012746);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (142, 2005, 0.082799414415304);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (143, 2005, 0.756212600610289);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (144, 2005, 0.113178769915565);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (145, 2005, 0.241306789177879);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (146, 2005, 5.63754527425395);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (147, 2005, 0.142850009767606);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (148, 2005, 4.77939102931666);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (149, 2005, 0.385104594599006);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (150, 2005, 0.28243130665195);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (151, 2005, 0.246996539187559);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (152, 2005, 0.335331376006792);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (153, 2005, 254.020641275545);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (154, 2005, 1325.29171981176);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (155, 2005, 189.347788254298);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (156, 2005, 50.067862006355);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (157, 2005, 309.851856390172);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (158, 2005, 341.069836586164);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (159, 2005, 434.954376574773);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (160, 2005, 12.804887371917);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (161, 2005, 124.351714711844);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (1, 2005, 45003.9716523846);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (2, 2005, 32365.5716523846);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (3, 2005, 13845.4998619202);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (4, 2005, 1207.09986192021);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (5, 2005, 12638.4);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (6, 2005, 2739.11085964659);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (7, 2005, 767.174511583887);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (8, 2005, 286.084439421138);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (9, 2005, 0.861702759703969);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (10, 2005, 5.99776961902145);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (11, 2005, 3.00931293446558);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (12, 2005, 1.0968779641559);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (13, 2005, 2.95294425827954);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (14, 2005, 18.7372566145184);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (15, 2005, 37.3667731827381);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (16, 2005, 0.287088545229977);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (17, 2005, 26.6309183472222);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (18, 2005, 16.8883120795306);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (19, 2005, 0.441177938419178);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (20, 2005, 31.7746390003223);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (21, 2005, 4.69446171361782);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (22, 2005, 8.20145737213168);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (23, 2005, 9.01904918602786);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (24, 2005, 4.69224508944148);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (25, 2005, 15.4603268222736);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (26, 2005, 84.1652080601239);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (27, 2005, 0.434243051768884);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (28, 2005, 0.797344040215946);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (29, 2005, 0.433760788002971);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (30, 2005, 12.1415700539273);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (31, 2005, 1685.85190864157);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (32, 2005, 173.941749522007);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (33, 2005, 980.339719423043);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (34, 2005, 531.570439696517);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (35, 2005, 9.2213606806389);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (36, 2005, 122.320602669516);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (37, 2005, 119.838795021645);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (38, 2005, 35.2045022875939);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (39, 2005, 0.749256078845679);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (40, 2005, 8.48504681709746);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (41, 2005, 79.2162347583725);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (42, 2005, 1.22767274436391);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (43, 2005, 17.6427700826911);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (44, 2005, 137.664198555753);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (45, 2005, 14403.3947950078);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (46, 2005, 13623.5028227577);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (47, 2005, 12795.3335109118);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (48, 2005, 306.898104143474);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (49, 2005, 403.782999568928);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (50, 2005, 368.532449516063);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (51, 2005, 35.2505500528647);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (52, 2005, 261.983756719442);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (53, 2005, 196.328945296617);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (54, 2005, 2155.43251784349);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (55, 2005, 2799.5370209724);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (56, 2005, 216.813983351113);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (57, 2005, 198.533087499718);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (58, 2005, 1750.69816302059);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (59, 2005, 603.000317932518);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (60, 2005, 173.20983811057);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (61, 2005, 1133.6240823257);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (62, 2005, 357.174339284205);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (63, 2005, 2238.31635484306);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (64, 2005, 828.16931184592);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (65, 2005, 26.6886681108071);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (66, 2005, 16.9231877674757);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (67, 2005, 128.967707284054);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (68, 2005, 13.2511481727277);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (69, 2005, 103.238533002398);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (70, 2005, 15.7198799339479);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (71, 2005, 25.4504458431083);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (72, 2005, 5.63964314267012);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (73, 2005, 307.375942862462);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (74, 2005, 102.219975144549);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (75, 2005, 48.4108682358846);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (76, 2005, 34.2833123458348);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (77, 2005, 779.891972250098);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (78, 2005, 674.875774563826);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (79, 2005, 15.0435146952273);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (80, 2005, 294.836901553505);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (81, 2005, 364.995358315094);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (82, 2005, 105.016197686272);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (83, 2005, 12.0358992712621);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (84, 2005, 8.97653555709576);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (85, 2005, 37.4974967950272);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (86, 2005, 5.70915351850297);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (87, 2005, 40.7971125443842);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (88, 2005, 1024.3524632599);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (89, 2005, 794.037512949945);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (90, 2005, 84.1046455937024);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (91, 2005, 146.21030471625);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (92, 2005, 5.02987037222024);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (93, 2005, 13.9942665135279);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (94, 2005, 35.8331590921167);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (95, 2005, 6.59441359381126);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (96, 2005, 57.7860538483234);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (97, 2005, 2.38193812373521);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (98, 2005, 2.84980125352881);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (99, 2005, 2.46015259311854);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (100, 2005, 7.40692548882009);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (101, 2005, 11.8737238370474);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (102, 2005, 10714.8764741391);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (103, 2005, 9884.17749778274);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (104, 2005, 5600.01858635876);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (105, 2005, 7966.63240256585);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (106, 2005, 3682.47349114187);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (107, 2005, 2300.31236178387);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (108, 2005, 173.394630015033);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (109, 2005, 4284.15891142398);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (110, 2005, 846.826334739724);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (111, 2005, 351.876026697968);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (112, 2005, 10.0641379052741);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (113, 2005, 7.94987250731461);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (114, 2005, 2.11426539795953);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (115, 2005, 951.12016101008);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (116, 2005, 298.692316113304);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (117, 2005, 134.819997327156);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (118, 2005, 104.017176577982);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (119, 2005, 187.534208472635);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (120, 2005, 52.3270535901572);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (121, 2005, 173.729408928846);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (122, 2005, 8.74851067131446);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (123, 2005, 37.7397109487321);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (124, 2005, 5.49759233219274);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (125, 2005, 2.95904789009709);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (126, 2005, 118.784547086509);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (127, 2005, 966.424934206808);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (128, 2005, 53.5509044921261);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (129, 2005, 757.87113497395);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (162, 2005, 12.6019180260257);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (163, 2005, 71.6553179340796);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (164, 2005, 21.684561072157);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (165, 2005, 29.9728130178685);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (166, 2005, 26.6044763727641);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (167, 2005, 127.872432298771);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (168, 2005, 3.0934372437185);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (169, 2005, 4.3128185256278);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (170, 2005, 951.445478599221);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (171, 2005, 315.803765015578);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (172, 2005, 99.7667881398681);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (173, 2005, 97.6379101245247);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (174, 2005, 38.557491338586);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (175, 2005, 51.906285352053);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (176, 2005, 27.9352900605458);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (177, 2005, 473.511867913359);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (178, 2005, 635.641713583643);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (179, 2005, 222.681092925187);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (180, 2005, 412.960620658456);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (181, 2005, 32.5468693094362);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (182, 2005, 4.40883934861956);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (183, 2005, 8.16124319411752);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (184, 2005, 5.68572494223304);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (185, 2005, 0.718384037211831);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (186, 2005, 16.6874657519151);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (187, 2005, 1.0558624016664);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (188, 2005, 1.38924372934845);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (189, 2005, 5.64868417624303);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (190, 2005, 0.385025155319806);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (191, 2005, 4.50953678474113);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (192, 2005, 16.2589246553216);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (193, 2005, 0.670806550251464);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (194, 2005, 3.65824891994882);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (195, 2005, 0.920379428266362);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (196, 2005, 9.47104137649603);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (197, 2005, 8.16554603204799);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (198, 2005, 0.324475758619986);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (199, 2005, 10.6435452010016);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (200, 2005, 3.20290374505879);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (201, 2005, 0.326485365346374);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (202, 2005, 19.4181118815894);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (203, 2005, 0.966775609647031);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (204, 2005, 0.810382997399285);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (205, 2005, 5.54558056666851);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (206, 2005, 2.64866592542323);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (207, 2005, 5.67225138218041);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (208, 2005, 1.82775212551098);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (209, 2005, 5.93550315546167);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (210, 2005, 5.91660777968284);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (211, 2005, 5.98403299449463);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (212, 2005, 3.43258598454423);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (213, 2005, 92.6603487954443);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (214, 2005, 4.80006085317743);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (215, 2005, 0.0708176326298765);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (216, 2005, 8.4104875058277);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (217, 2005, 0.619669334707635);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (218, 2005, 0.855837576229467);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (219, 2005, 28.7372854232894);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (220, 2005, 2.59927306654227);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (221, 2005, 10.8601551613036);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (222, 2005, 2.37032272763332);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (223, 2005, 8.98214557524258);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (224, 2005, 49.7178736126938);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (225, 2005, 8.86275900103866);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (226, 2005, 0.416098126882718);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (229, 2005, 32402.0981486128);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (230, 2005, 19763.6981486128);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (231, 2005, 10666.8983618898);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (232, 2005, 1722.87808726594);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (233, 2005, 560.905817684123);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (234, 2005, 8383.11445693975);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (235, 2005, 1934.97514188194);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (236, 2005, 8404.92655537444);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (237, 2005, 12601.8735037718);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (130, 2006, 121.009744786722);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (131, 2006, 44.5996206016744);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (132, 2006, 11.3401640899415);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (133, 2006, 1.02483824664547);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (134, 2006, 7.68544994025563);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (135, 2006, 24.5491683248318);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (136, 2006, 853.565928251676);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (137, 2006, 721.921220676414);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (138, 2006, 102.169903459209);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (139, 2006, 29.4748041160536);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (140, 2006, 3.05775948559785);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (141, 2006, 6.77641075723129);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (142, 2006, 0.0856145945054243);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (143, 2006, 0.900545078510862);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (144, 2006, 0.116574133013032);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (145, 2006, 0.23969951097237);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (146, 2006, 5.80667163248156);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (147, 2006, 0.147135510060634);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (148, 2006, 4.90365519607889);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (149, 2006, 0.393962000274783);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (150, 2006, 0.299548355539947);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (151, 2006, 0.250207494196998);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (152, 2006, 0.353774601687165);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (153, 2006, 273.069974266261);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (154, 2006, 1420.96535313527);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (155, 2006, 200.422545354019);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (156, 2006, 69.9149427450681);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (157, 2006, 323.160561807855);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (158, 2006, 364.581446701214);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (159, 2006, 462.885856527115);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (160, 2006, 13.6372050510916);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (161, 2006, 130.831037678168);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (1, 2006, 46793.9688820402);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (2, 2006, 33817.7688820402);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (3, 2006, 14216.7559624605);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (4, 2006, 1240.55596246053);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (5, 2006, 12976.2);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (6, 2006, 2877.22080468945);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (7, 2006, 803.774445443219);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (8, 2006, 299.249980709896);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (9, 2006, 0.969238894735812);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (10, 2006, 6.23768040378231);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (11, 2006, 3.11463888717187);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (12, 2006, 1.16049688607695);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (13, 2006, 3.11098108522099);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (14, 2006, 20.3887569885449);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (15, 2006, 38.7119770173167);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (16, 2006, 0.293117404679806);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (17, 2006, 29.4727448810722);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (18, 2006, 17.5949581694996);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (19, 2006, 0.444575008545005);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (20, 2006, 33.4557091696235);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (21, 2006, 4.80323432606719);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (22, 2006, 8.69591590214737);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (23, 2006, 9.24118457658158);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (24, 2006, 4.86543075583319);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (25, 2006, 16.7980152717209);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (26, 2006, 84.9544329147288);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (27, 2006, 0.461904334166562);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (28, 2006, 0.82955673944067);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (29, 2006, 0.47154135263803);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (30, 2006, 13.1738897403017);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (31, 2006, 1774.19637853634);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (32, 2006, 188.665814715082);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (33, 2006, 1016.49345531868);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (34, 2006, 569.037108502574);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (35, 2006, 9.64833781517517);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (36, 2006, 127.859897277166);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (37, 2006, 128.039014187845);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (38, 2006, 36.5748247776352);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (39, 2006, 0.773981529447587);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (40, 2006, 8.85334410675391);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (41, 2006, 85.2024890775409);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (42, 2006, 1.29883894560906);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (43, 2006, 18.877688738747);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (44, 2006, 151.908692046654);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (45, 2006, 14849.6535916982);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (46, 2006, 14044.1509239459);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (47, 2006, 13162.3960863037);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (48, 2006, 316.526057566222);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (49, 2006, 416.749033008584);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (50, 2006, 379.322102605354);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (51, 2006, 37.4269304032308);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (52, 2006, 271.357741233952);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (53, 2006, 205.859107637979);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (54, 2006, 2202.76180879663);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (55, 2006, 2883.12049468149);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (56, 2006, 225.908872381746);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (57, 2006, 209.919140840785);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (58, 2006, 1782.92807557946);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (59, 2006, 621.121378174123);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (60, 2006, 175.536367997079);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (61, 2006, 1177.38428911674);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (62, 2006, 373.071230645937);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (63, 2006, 2300.15248864297);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (64, 2006, 881.754837642171);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (65, 2006, 28.376492734082);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (66, 2006, 17.6075787045336);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (67, 2006, 137.170043078041);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (68, 2006, 14.7336552022371);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (69, 2006, 107.257034046937);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (70, 2006, 17.6431457953547);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (71, 2006, 27.4006893665979);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (72, 2006, 5.83300293504414);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (73, 2006, 326.597599287909);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (74, 2006, 110.345498210973);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (75, 2006, 52.5434226916083);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (76, 2006, 36.246675588853);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (77, 2006, 805.502667752319);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (78, 2006, 694.794057346105);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (79, 2006, 15.7097606543354);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (80, 2006, 302.285944301844);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (81, 2006, 376.798352389925);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (82, 2006, 110.708610406214);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (83, 2006, 12.6590778018608);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (84, 2006, 9.72373039960395);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (85, 2006, 39.2832557055855);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (86, 2006, 5.92106940614167);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (87, 2006, 43.1214770930223);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (88, 2006, 1107.99531219611);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (89, 2006, 852.796288908241);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (90, 2006, 90.3607971527344);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (91, 2006, 164.838226135133);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (92, 2006, 5.70387300209775);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (93, 2006, 18.8222884606951);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (94, 2006, 39.3806418422362);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (95, 2006, 7.21109528161869);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (96, 2006, 63.889063938413);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (97, 2006, 2.455778205571);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (98, 2006, 2.98615433353251);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (99, 2006, 2.63236327463684);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (100, 2006, 9.01646211917985);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (101, 2006, 12.7405056771519);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (102, 2006, 11316.9452612372);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (103, 2006, 10463.3793329855);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (104, 2006, 6084.54217159234);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (105, 2006, 8400.58623222632);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (106, 2006, 4021.74907083319);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (107, 2006, 2567.1485957508);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (108, 2006, 185.563569718769);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (109, 2006, 4378.83716139314);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (110, 2006, 889.110450960009);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (111, 2006, 368.329483686607);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (112, 2006, 11.5969707170069);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (113, 2006, 9.30510702561873);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (114, 2006, 2.29186369138813);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (115, 2006, 1008.76900809723);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (116, 2006, 315.15159043665);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (117, 2006, 142.820360441126);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (118, 2006, 109.683183671927);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (119, 2006, 197.112284947533);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (120, 2006, 56.6030097684662);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (121, 2006, 187.398578831526);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (122, 2006, 9.19468471555149);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (123, 2006, 40.4192304260921);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (124, 2006, 6.09129897495108);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (125, 2006, 3.20414762798903);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (126, 2006, 128.489217086942);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (127, 2006, 1054.02409266193);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (128, 2006, 57.100973181378);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (129, 2006, 831.313754092153);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (162, 2006, 13.3967801603529);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (163, 2006, 76.1561936385483);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (164, 2006, 21.1424470453531);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (165, 2006, 31.681263359887);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (166, 2006, 27.9613301971348);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (167, 2006, 139.877257446851);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (168, 2006, 3.70599907415781);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (169, 2006, 4.49634287556941);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (170, 2006, 1004.43259662347);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (171, 2006, 331.631873626419);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (172, 2006, 101.610750201224);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (173, 2006, 104.277288012992);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (174, 2006, 40.5488070383927);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (175, 2006, 55.7435829510871);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (176, 2006, 29.4514454227237);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (177, 2006, 503.434663565507);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (178, 2006, 672.800722997052);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (179, 2006, 233.238015985928);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (180, 2006, 439.562707011123);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (181, 2006, 38.6005870009912);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (182, 2006, 4.63368249254788);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (183, 2006, 8.45586407342517);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (184, 2006, 5.91315175941597);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (185, 2006, 0.760644789787426);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (186, 2006, 17.2214646559763);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (187, 2006, 1.16989554104638);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (188, 2006, 1.4420349910637);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (189, 2006, 5.67692759712424);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (190, 2006, 0.390030482338963);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (191, 2006, 4.79075149863759);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (192, 2006, 16.2101478813557);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (193, 2006, 0.698978556129408);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (194, 2006, 3.46801997611148);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (195, 2006, 0.93878701683169);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (196, 2006, 10.565893759619);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (197, 2006, 8.26353258443257);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (198, 2006, 0.330568215561982);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (199, 2006, 11.3247320938657);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (200, 2006, 3.36455339156899);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (201, 2006, 0.332195500337);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (202, 2006, 20.5831985944847);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (203, 2006, 1.03445538110365);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (204, 2006, 0.860626743238041);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (205, 2006, 5.81731401443527);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (206, 2006, 2.85791053353167);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (207, 2006, 5.93325694235604);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (208, 2006, 2.03611586781923);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (209, 2006, 6.14324576590283);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (210, 2006, 6.41971641865243);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (211, 2006, 6.22937826726847);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (212, 2006, 3.61108045574053);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (213, 2006, 97.834776226704);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (214, 2006, 5.05446407839583);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (215, 2006, 0.0743585142613703);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (216, 2006, 8.57869725594425);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (217, 2006, 0.65251180944714);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (218, 2006, 0.929439607785202);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (219, 2006, 31.9814375747245);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (220, 2006, 2.65125852787311);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (221, 2006, 11.5334847813044);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (222, 2006, 2.41772918218598);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (223, 2006, 9.46718143630568);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (224, 2006, 52.495278013481);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (225, 2006, 9.41154779645941);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (226, 2006, 0.401799363550198);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (229, 2006, 33276.8743916391);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (230, 2006, 20300.6743916391);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (231, 2006, 11440.0763117962);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (232, 2006, 1812.70837131708);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (233, 2006, 593.707166019785);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (234, 2006, 9033.6607744593);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (235, 2006, 2077.01817860492);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (236, 2006, 9030.25411689401);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (237, 2006, 13517.0944904011);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (130, 2007, 128.736437515388);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (131, 2007, 48.0595556122953);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (132, 2007, 12.7576846011842);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (133, 2007, 1.20316010156178);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (134, 2007, 7.87697448919813);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (135, 2007, 26.2217364203512);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (136, 2007, 888.359920416399);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (137, 2007, 752.619683442783);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (138, 2007, 105.434515759078);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (139, 2007, 30.3057212145375);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (140, 2007, 2.85594735954839);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (141, 2007, 6.92406591847987);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (142, 2007, 0.0851865215328971);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (143, 2007, 0.965384324163645);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (144, 2007, 0.120071357003423);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (145, 2007, 0.232175838239544);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (146, 2007, 5.98087178145601);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (147, 2007, 0.151549575362453);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (148, 2007, 5.22347158796716);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (149, 2007, 0.416417834290446);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (150, 2007, 0.330281238770669);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (151, 2007, 0.241450244881036);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (152, 2007, 0.377831274601892);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (153, 2007, 293.013130093137);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (154, 2007, 1489.59278817213);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (155, 2007, 216.105185270773);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (156, 2007, 70.200584780759);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (157, 2007, 334.115632308988);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (158, 2007, 380.814151881961);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (159, 2007, 488.357233929646);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (160, 2007, 14.7805336242484);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (161, 2007, 137.854092770477);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (1, 2007, 48534.8745802867);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (2, 2007, 35305.9745802867);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (3, 2007, 14503.1162080914);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (4, 2007, 1274.21620809145);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (5, 2007, 13228.9);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (6, 2007, 3027.47873826169);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (7, 2007, 830.250178927108);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (8, 2007, 312.085906311072);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (9, 2007, 1.03030094510417);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (10, 2007, 6.3591292610619);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (11, 2007, 3.21742197044855);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (12, 2007, 1.17872671868842);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (13, 2007, 3.25523487112358);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (14, 2007, 21.9781556670963);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (15, 2007, 41.595533382547);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (16, 2007, 0.30220404422488);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (17, 2007, 31.970449421605);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (18, 2007, 18.4131262743493);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (19, 2007, 0.46013513384408);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (20, 2007, 35.5529547276595);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (21, 2007, 4.9041022469146);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (22, 2007, 9.24379099442069);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (23, 2007, 9.37326576593433);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (24, 2007, 5.01872381076243);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (25, 2007, 18.7370194363395);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (26, 2007, 83.7792848274912);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (27, 2007, 0.476223368525726);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (28, 2007, 0.833704523137874);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (29, 2007, 0.507850036791158);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (30, 2007, 13.8985688830015);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (31, 2007, 1885.14265302351);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (32, 2007, 204.969908354731);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (33, 2007, 1071.50338498747);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (34, 2007, 608.669359681306);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (35, 2007, 10.0887250468334);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (36, 2007, 133.934258086803);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (37, 2007, 137.700670455908);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (38, 2007, 37.4873495271719);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (39, 2007, 0.815240833066341);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (40, 2007, 9.4519456662317);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (41, 2007, 92.7486451893936);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (42, 2007, 1.3688732570375);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (43, 2007, 20.3089295722954);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (44, 2007, 164.764722046566);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (45, 2007, 15280.2792878735);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (46, 2007, 14444.3421826108);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (47, 2007, 13507.8195367358);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (48, 2007, 326.13838492144);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (49, 2007, 428.547117407443);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (50, 2007, 389.177452525305);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (51, 2007, 39.369664882138);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (52, 2007, 276.750383907462);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (53, 2007, 214.509454358795);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (54, 2007, 2252.54067998294);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (55, 2007, 2957.63710581328);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (56, 2007, 235.026473483119);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (57, 2007, 222.566907189629);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (58, 2007, 1809.03930636048);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (59, 2007, 643.561866429201);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (60, 2007, 178.822875745542);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (61, 2007, 1220.52471531389);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (62, 2007, 383.136998950512);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (63, 2007, 2359.0172668721);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (64, 2007, 936.522645874997);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (65, 2007, 30.1348749772419);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (66, 2007, 18.375545990011);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (67, 2007, 145.586122686579);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (68, 2007, 15.6667259768991);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (69, 2007, 108.698346106131);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (70, 2007, 19.403510313918);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (71, 2007, 29.8461230892791);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (72, 2007, 6.07999638213102);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (73, 2007, 348.817663958161);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (74, 2007, 117.195011623369);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (75, 2007, 58.0201232106146);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (76, 2007, 38.6986015606632);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (77, 2007, 835.937105262675);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (78, 2007, 717.776658919308);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (79, 2007, 16.5756699677111);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (80, 2007, 311.870403677933);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (81, 2007, 389.330585273664);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (82, 2007, 118.160446343367);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (83, 2007, 13.4541362013393);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (84, 2007, 10.9043240335464);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (85, 2007, 41.432605474219);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (86, 2007, 6.27041250110403);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (87, 2007, 46.0989681331581);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (88, 2007, 1202.12870897051);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (89, 2007, 921.872788309809);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (90, 2007, 97.3433363279619);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (91, 2007, 182.912584332736);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (92, 2007, 6.46819198437885);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (93, 2007, 23.5370834972145);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (94, 2007, 42.6098544732996);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (95, 2007, 8.10742057469622);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (96, 2007, 69.5973981659285);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (97, 2007, 2.66451935304454);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (98, 2007, 3.07720346180766);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (99, 2007, 2.83768760315893);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (100, 2007, 10.0623717250047);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (101, 2007, 13.9508534942028);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (102, 2007, 11967.207626553);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (103, 2007, 11078.8477061366);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (104, 2007, 6610.9675193879);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (105, 2007, 8861.99825881276);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (106, 2007, 4394.11807206408);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (107, 2007, 2859.80353566639);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (108, 2007, 197.379509906294);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (109, 2007, 4467.88018674868);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (110, 2007, 933.324045827731);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (111, 2007, 389.40750792215);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (112, 2007, 14.2034727415133);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (113, 2007, 11.6847145446777);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (114, 2007, 2.51875819683555);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (115, 2007, 1072.92856612296);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (116, 2007, 334.937231400069);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (117, 2007, 151.755198727953);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (118, 2007, 117.565954093121);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (119, 2007, 206.822516172699);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (120, 2007, 61.40328520433);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (121, 2007, 200.444380524791);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (122, 2007, 9.2498528238448);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (123, 2007, 42.561449638675);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (124, 2007, 6.72097178032268);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (125, 2007, 3.44410088705811);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (126, 2007, 138.468005394891);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (127, 2007, 1143.92088120086);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (128, 2007, 60.7711535639387);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (129, 2007, 906.353734509235);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (162, 2007, 14.5906162986116);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (163, 2007, 79.4784735436731);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (164, 2007, 22.7281305737545);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (165, 2007, 33.6138204248401);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (166, 2007, 29.7309201014991);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (167, 2007, 147.193562528592);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (168, 2007, 3.71);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (169, 2007, 4.6770840639501);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (170, 2007, 1065.07122236446);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (171, 2007, 347.962143780281);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (172, 2007, 105.042091901787);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (173, 2007, 111.785252749928);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (174, 2007, 42.8680783526443);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (175, 2007, 56.969941776011);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (176, 2007, 31.2967789999107);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (177, 2007, 531.22531228229);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (178, 2007, 717.109078584178);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (179, 2007, 245.227422004673);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (180, 2007, 471.881656579504);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (181, 2007, 46.7453108582004);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (182, 2007, 4.84683188720508);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (183, 2007, 8.97729193389502);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (184, 2007, 6.12602522275494);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (185, 2007, 0.788788647009561);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (186, 2007, 17.7897729896236);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (187, 2007, 1.26074962876404);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (188, 2007, 1.49394825074199);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (189, 2007, 5.68714606679907);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (190, 2007, 0.378670371202877);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (191, 2007, 4.71457854980926);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (192, 2007, 16.4695102474574);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (193, 2007, 0.740917269497172);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (194, 2007, 3.81482197372263);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (195, 2007, 0.950991248050501);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (196, 2007, 11.7735754163434);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (197, 2007, 8.72629040916079);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (198, 2007, 0.351394013142387);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (199, 2007, 12.0381902157793);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (200, 2007, 3.41534992053603);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (201, 2007, 0.341164778846099);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (202, 2007, 22.0283449678035);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (203, 2007, 1.08509627324242);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (204, 2007, 0.942386283845655);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (205, 2007, 6.18476100899507);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (206, 2007, 3.06947889639328);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (207, 2007, 6.08032421986446);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (208, 2007, 2.05392781568424);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (209, 2007, 6.40101635824012);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (210, 2007, 6.86909656793153);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (211, 2007, 6.50388859721042);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (212, 2007, 3.73024611077997);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (213, 2007, 104.144883893987);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (214, 2007, 5.4537667405891);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (215, 2007, 0.0788200251170526);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (216, 2007, 8.98618537560161);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (217, 2007, 0.686896014520116);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (218, 2007, 0.988923742683455);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (219, 2007, 35.2317110754438);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (220, 2007, 2.71403204378403);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (221, 2007, 12.3578982734721);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (222, 2007, 2.46366603664752);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (223, 2007, 10.2802229780556);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (224, 2007, 55.7797072109762);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (225, 2007, 9.95773456203);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (226, 2007, 0.377321608064958);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (229, 2007, 34054.6467896971);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (230, 2007, 20825.7467896971);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (231, 2007, 12247.8715317728);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (232, 2007, 1908.43559124438);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (233, 2007, 618.431875254186);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (234, 2007, 9721.00406527429);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (235, 2007, 2232.35625881673);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (236, 2007, 9718.52388119124);
insert into gdp_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (237, 2007, 14480.2277905896);
commit;
