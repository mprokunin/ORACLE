drop table economic_entity;

drop table gdp_by_year;

drop table gdp_growth_by_year;

