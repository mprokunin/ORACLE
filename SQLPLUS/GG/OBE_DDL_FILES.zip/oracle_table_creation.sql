create table economic_entity
(
  entity_id        integer      not null,
  economic_entity  varchar2(128) not null,
  continent	   varchar2(20),
  PRIMARY KEY(entity_id)
);

create table gdp_by_year
(
  entity_id     integer not null,
  gdp_year      integer not null,
  gdp_value     number(15,5) not null,
  PRIMARY KEY (entity_id,gdp_year)
);

create table gdp_growth_by_year
(
  entity_id         integer not null,
  gdp_year          integer not null,
  gdp_value         number(15,5) not null,
  PRIMARY KEY (entity_id,gdp_year)
);


