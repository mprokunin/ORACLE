insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (133, 2005, 8.00000000000001);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (134, 2005, 2.31987016736728);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (135, 2005, 6.01751774206707);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (136, 2005, 2.47238419611533);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (137, 2005, 2.54242277242178);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (138, 2005, 1.94757091308815);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (139, 2005, 2.59693014604774);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (140, 2005, 1.49999999999999);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (141, 2005, 2.63);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (142, 2005, 0.299999999999989);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (143, 2005, -5.52993984549148);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (144, 2005, 3);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (145, 2005, 1.4);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (146, 2005, 8.01);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (147, 2005, 3);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (148, 2005, 2.99999999999998);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (149, 2005, 3.70000000000001);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (150, 2005, 4.79999999999998);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (151, 2005, 2.29999999999997);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (152, 2005, 3.10000000000001);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (153, 2005, 6.89161975431773);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (154, 2005, 6.03906984073221);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (155, 2005, 4.66792305371297);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (156, 2005, 47.4922347180782);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (157, 2005, 6.55424669712101);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (158, 2005, 7.38012006502178);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (159, 2005, 5.57064271333052);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (160, 2005, 6.00000000000003);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (161, 2005, 5.19303070894104);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (162, 2005, 7.22859419152815);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (163, 2005, 5.80000000000001);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (164, 2005, 1.00001166345489);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (165, 2005, 4.6);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (1, 2005, 3.37367760811662);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (2, 2005, 3.49884320000851);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (3, 2005, 3.02671423997407);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (4, 2005, 2.73650387885891);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (5, 2005, 3.05451817544318);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (6, 2005, 4.0074693931353);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (7, 2005, 2.80412678346433);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (8, 2005, 2.84127951664837);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (9, 2005, 3.15035100000001);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (10, 2005, 3.4);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (11, 2005, 4.09999999999997);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (12, 2005, 3.6);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (13, 2005, 2.30000000000001);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (14, 2005, 5.94665389300499);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (15, 2005, 3.50000000000004);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (16, 2005, 2.10000000000001);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (17, 2005, 9.28698665413172);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (18, 2005, 2.75161349523643);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (19, 2005, 1.99999999999998);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (20, 2005, 3.24185247789119);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (21, 2005, 1.79169809583692);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (22, 2005, 4.14954395108751);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (23, 2005, 1.40325710935407);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (24, 2005, 3.98305090343876);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (25, 2005, 6.37138561802211);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (26, 2005, 0.271731826123589);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (27, 2005, 4.09999999999997);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (28, 2005, 5.4);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (29, 2005, 3.08999999999997);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (30, 2005, 15.39);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (31, 2005, 4.76713154110231);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (32, 2005, 9.19205355865833);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (33, 2005, 2.94339997257187);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (34, 2005, 6.84110496161134);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (35, 2005, 4.05517236926953);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (36, 2005, 6.34793318581248);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (37, 2005, 5.1953337130487);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (38, 2005, 3.93241875776558);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (39, 2005, -3.00698049042417);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (40, 2005, 2.69930737911421);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (41, 2005, 6.63203225241042);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (42, 2005, 4.89999999999997);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (43, 2005, 6.56050480179919);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (44, 2005, 10.3);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (45, 2005, 1.89438242176541);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (46, 2005, 1.85379379006945);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (47, 2005, 1.68252725122373);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (48, 2005, 1.92159237485379);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (49, 2005, 1.75230063382605);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (50, 2005, 1.53918801929322);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (51, 2005, 4.03508630813529);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (52, 2005, 3.35652861417193);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (53, 2005, 3.28212818942919);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (54, 2005, 1.71955671447155);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (55, 2005, 1.09601816517448);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (56, 2005, 3.65777232485678);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (57, 2005, 4.65684587320163);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (58, 2005, 0.107104896061028);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (59, 2005, 1.52981525277296);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (60, 2005, 0.36581040523842);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (61, 2005, 3.42659736746613);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (62, 2005, 2.70000000000001);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (63, 2005, 1.9320153193612);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (64, 2005, 4.57516138817162);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (65, 2005, 5.48614606218321);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (66, 2005, 3.75022238035934);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (67, 2005, 6.0900235095203);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (68, 2005, 9.77957268087568);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (69, 2005, 4.11586776471575);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (70, 2005, 10.2);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (71, 2005, 7.5);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (72, 2005, 2.35079503440927);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (73, 2005, 3.4);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (74, 2005, 4.09999999999999);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (75, 2005, 6.12506000557322);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (76, 2005, 3.87961573591264);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (77, 2005, 2.60865757449689);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (78, 2005, 2.20977368669477);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (79, 2005, 5.59073943657435);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (80, 2005, 2.49122538824653);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (81, 2005, 1.8494343312941);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (82, 2005, 5.24824767182925);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (83, 2005, 5.50086348694228);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (84, 2005, 5.48539083890305);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (85, 2005, 4.28424964757146);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (86, 2005, 3.95581112401289);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (87, 2005, 6.2078427396947);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (88, 2005, 6.68046568065699);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (89, 2005, 6.36762992687214);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (90, 2005, 2.60000000000002);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (91, 2005, 10.9924872198215);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (92, 2005, 13.9416271405765);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (93, 2005, 26.4);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (94, 2005, 9.19999999999999);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (95, 2005, 9.22557170272256);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (96, 2005, 9.45168094347702);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (97, 2005, -0.600000000000001);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (98, 2005, 7.1);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (99, 2005, 6.69999999999999);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (100, 2005, 4.09);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (101, 2005, 7.00000000000001);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (102, 2005, 4.90029980396414);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (103, 2005, 5.10960127186655);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (104, 2005, 7.72846296475531);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (105, 2005, 4.67289755903961);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (106, 2005, 8.13107169959846);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (107, 2005, 10.3986157717259);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (108, 2005, 7.2707130663721);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (109, 2005, 1.87245178540938);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (110, 2005, 4.19763528726045);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (111, 2005, 6.26);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (112, 2005, 6.57029361955008);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (113, 2005, 6.65982447480991);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (114, 2005, 6.23498856077445);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (115, 2005, 5.7405523131733);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (116, 2005, 5.59631589490674);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (117, 2005, 5.15855507512615);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (118, 2005, 4.97303358694086);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (119, 2005, 4.46411605130446);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (120, 2005, 8.3509539854117);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (121, 2005, 7.56423509769597);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (122, 2005, 3.09999999999999);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (123, 2005, 12.2);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (124, 2005, 11.3730306561904);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (125, 2005, 6.9982136597313);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (126, 2005, 6.35298195803964);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (127, 2005, 8.19529536830998);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (128, 2005, 5.37540481330963);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (129, 2005, 8.4300158173982);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (130, 2005, 8.35260682071173);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (131, 2005, 7.24009169544713);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (132, 2005, 13.9);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (166, 2005, 3.46350768987467);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (167, 2005, 7.20000000000001);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (168, 2005, 4.84429065743943);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (169, 2005, 3.7);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (170, 2005, 5.37212276091179);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (171, 2005, 4.15552782565911);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (172, 2005, 5.09999999999999);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (173, 2005, 4.89817907553067);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (174, 2005, 3.53469341365005);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (175, 2005, 1.47999999999995);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (176, 2005, 4.20000000000003);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (177, 2005, 5.40186804384768);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (178, 2005, 5.98718911143548);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (179, 2005, 4.87182180434551);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (180, 2005, 6.59853222880213);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (181, 2005, 15.7);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (182, 2005, 4.79999999999998);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (183, 2005, 4.79999999999992);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (184, 2005, 7.08699124634402);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (185, 2005, 5.00000000000003);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (186, 2005, 2.59999999999998);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (187, 2005, 6.30000000000002);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (188, 2005, 2.8);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (189, 2005, 10.1);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (190, 2005, 2.8);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (191, 2005, 7.7);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (192, 2005, 0.600000000000045);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (193, 2005, 3.20046950652908);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (194, 2005, 9.20000000000001);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (195, 2005, 0.499999999999989);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (196, 2005, 8.60000000000001);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (197, 2005, 2.70000000000001);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (198, 2005, 4.50000000000002);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (199, 2005, 5.80000000000001);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (200, 2005, 3);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (201, 2005, 2.29999999999999);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (202, 2005, 5);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (203, 2005, 1.2);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (204, 2005, 7.5);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (205, 2005, 5.49999999999999);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (206, 2005, 2.00000000000002);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (207, 2005, 5.4);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (208, 2005, 5.49999999999999);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (209, 2005, 3);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (210, 2005, 7.69975219985417);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (211, 2005, 3.8);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (212, 2005, 3.49999999999997);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (213, 2005, 6.90214920889072);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (214, 2005, 3.21750000000001);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (215, 2005, 3.8);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (216, 2005, 6.20000000000003);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (217, 2005, 1);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (218, 2005, 7.53005885178555);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (219, 2005, 8.00552104899932);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (220, 2005, 1.75000000000001);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (221, 2005, 6.80000000000001);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (222, 2005, 2.8);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (223, 2005, 5.50000000000002);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (224, 2005, 7.8836668447545);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (225, 2005, 4.29997713326835);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (226, 2005, -10.3333463394332);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (229, 2005, 2.30852531041263);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (230, 2005, 1.8371165868347);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (231, 2005, 6.30577635355338);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (232, 2005, 4.4899641062059);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (233, 2005, 6.42890227037183);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (234, 2005, 6.6785166110201);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (235, 2005, 5.73050685080041);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (236, 2005, 6.30027665072941);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (237, 2005, 6.21703919820706);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (133, 2006, 17.1);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (134, 2006, 2.84560520563235);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (135, 2006, 7.38339834928394);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (136, 2006, 2.75273625539312);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (137, 2006, 2.78926107227817);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (138, 2006, 2.27348145175603);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (139, 2006, 3.53339267579669);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (140, 2006, 3.61085291904573);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (141, 2006, 3.63);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (142, 2006, 3.39999999999998);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (143, 2006, 19.0862302193976);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (144, 2006, 3);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (145, 2006, -0.666072517472682);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (146, 2006, 9.01);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (147, 2006, 2.99999999999998);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (148, 2006, 2.6);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (149, 2006, 2.29999999999999);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (150, 2006, 6.06060606060608);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (151, 2006, 1.29999999999999);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (152, 2006, 5.50000000000002);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (153, 2006, 7.49912798230148);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (154, 2006, 7.2190621802948);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (155, 2006, 5.84889699627618);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (156, 2006, 48.4922347180782);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (157, 2006, 4.29518337334893);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (158, 2006, 6.89348854486285);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (159, 2006, 6.42170339158321);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (160, 2006, 6.49999999999999);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (161, 2006, 5.21048140054912);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (162, 2006, 6.30746948746763);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (163, 2006, 6.28128635003673);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (164, 2006, -2.49999999999999);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (165, 2006, 5.69999999999997);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (1, 2006, 3.97742057852517);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (2, 2006, 4.48685796516306);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (3, 2006, 2.68142070884276);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (4, 2006, 2.77161000475183);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (5, 2006, 2.67280668439043);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (6, 2006, 5.04214513831978);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (7, 2006, 4.77074424484845);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (8, 2006, 4.60197741456907);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (9, 2006, 12.4794929366115);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (10, 2006, 4);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (11, 2006, 3.49999999999997);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (12, 2006, 5.80000000000001);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (13, 2006, 5.35183915166484);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (14, 2006, 8.81399240028997);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (15, 2006, 3.6000000000002);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (16, 2006, 3.10000000000001);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (17, 2006, 10.6711548463984);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (18, 2006, 4.18423159544488);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (19, 2006, 0.770000000000004);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (20, 2006, 5.29060351963146);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (21, 2006, 2.31704120908769);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (22, 2006, 6.02891056528381);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (23, 2006, 2.46295796787366);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (24, 2006, 3.69089131301796);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (25, 2006, 8.65239438224654);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (26, 2006, 0.937709147039878);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (27, 2006, 6.37000000000003);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (28, 2006, 4.03999999999998);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (29, 2006, 8.71000000000004);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (30, 2006, 16.39);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (31, 2006, 5.24034581222237);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (32, 2006, 8.46494026508116);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (33, 2006, 3.68787831190955);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (34, 2006, 7.04829802564784);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (35, 2006, 4.63030510706239);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (36, 2006, 4.52850499978041);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (37, 2006, 6.84270829385285);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (38, 2006, 3.89246375036578);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (39, 2006, 3.29999999999999);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (40, 2006, 4.34054516840532);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (41, 2006, 7.55685288177088);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (42, 2006, 5.79683808831548);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (43, 2006, 6.9995734811932);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (44, 2006, 10.3472752105064);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (45, 2006, 3.09828900090288);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (46, 2006, 3.08766480002074);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (47, 2006, 2.86872221875922);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (48, 2006, 3.13718243702388);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (49, 2006, 3.21113901612962);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (50, 2006, 2.92773488561417);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (51, 2006, 6.17403231184261);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (52, 2006, 3.57807851597016);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (53, 2006, 4.85418099046118);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (54, 2006, 2.19581409120124);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (55, 2006, 2.98561773189403);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (56, 2006, 4.19478895690253);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (57, 2006, 5.73509105432295);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (58, 2006, 1.84097483162147);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (59, 2006, 3.00514936770451);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (60, 2006, 1.34318576351506);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (61, 2006, 3.86020440755481);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (62, 2006, 4.45073724881528);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (63, 2006, 2.76261814672052);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (64, 2006, 6.47035878168603);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (65, 2006, 6.32412459200786);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (66, 2006, 4.0441017759858);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (67, 2006, 6.35999194427872);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (68, 2006, 11.1877628276808);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (69, 2006, 3.89244299359186);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (70, 2006, 12.234609103174);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (71, 2006, 7.66290514324184);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (72, 2006, 3.42858204823357);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (73, 2006, 6.25346806469103);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (74, 2006, 7.94905599901967);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (75, 2006, 8.53641879667937);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (76, 2006, 5.72687733090835);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (77, 2006, 3.28387730781869);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (78, 2006, 2.95139987728139);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (79, 2006, 4.42879189209386);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (80, 2006, 2.52649607599678);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (81, 2006, 3.23373813007271);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (82, 2006, 5.42050925986453);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (83, 2006, 5.17766488862752);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (84, 2006, 8.32386657141406);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (85, 2006, 4.76234165795055);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (86, 2006, 3.71186178392124);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (87, 2006, 5.69737514170747);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (88, 2006, 8.16543640360141);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (89, 2006, 7.40000000000001);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (90, 2006, 7.4385326932529);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (91, 2006, 12.7404983219442);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (92, 2006, 13.4);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (93, 2006, 34.5000000000004);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (94, 2006, 9.90000000000002);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (95, 2006, 9.35157734701635);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (96, 2006, 10.5613892689554);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (97, 2006, 3.10000000000001);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (98, 2006, 4.78465225723592);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (99, 2006, 7.00000000000005);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (100, 2006, 5.09);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (101, 2006, 7.29999999999997);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (102, 2006, 5.61899886154735);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (103, 2006, 5.85988905331445);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (104, 2006, 8.65217816265558);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (105, 2006, 5.44714262855546);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (106, 2006, 9.21325246488383);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (107, 2006, 11.6);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (108, 2006, 7.01806030710481);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (109, 2006, 2.20996120654369);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (110, 2006, 4.9932453072898);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (111, 2006, 7.26);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (112, 2006, 15.2306419701328);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (113, 2006, 17.0472484565908);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (114, 2006, 8.40000000000001);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (115, 2006, 6.06115288586941);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (116, 2006, 5.51044450607923);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (117, 2006, 5.93410715960501);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (118, 2006, 5.44718409050169);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (119, 2006, 5.10737563717363);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (120, 2006, 8.17159745281995);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (121, 2006, 7.8680805897859);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (122, 2006, 5.09999999999999);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (123, 2006, 7.09999999999997);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (124, 2006, 10.7993937506372);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (125, 2006, 8.28306086941704);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (126, 2006, 8.16997685175769);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (127, 2006, 9.06424858822743);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (128, 2006, 6.62933469176774);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (129, 2006, 9.69064735797427);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (130, 2006, 6.85688497994501);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (131, 2006, 6.80444125353481);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (132, 2006, 7.5);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (166, 2006, 5.10009595888832);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (167, 2006, 9.38812606616517);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (168, 2006, 19.8019801980198);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (169, 2006, 4.7);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (170, 2006, 5.56911764426706);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (171, 2006, 5.01200757060669);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (172, 2006, 1.84827245192081);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (173, 2006, 6.80000000000005);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (174, 2006, 5.16453646405641);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (175, 2006, 7.39274169401209);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (176, 2006, 5.42738363872997);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (177, 2006, 6.31933382874019);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (178, 2006, 5.84590479500038);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (179, 2006, 4.7408259597002);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (180, 2006, 6.44179735836576);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (181, 2006, 18.5999999999999);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (182, 2006, 5.09982619345657);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (183, 2006, 3.61);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (184, 2006, 3.99996164945684);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (185, 2006, 5.88275217523155);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (186, 2006, 3.2);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (187, 2006, 10.8);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (188, 2006, 3.8);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (189, 2006, 0.499999999999989);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (190, 2006, 1.29999999999999);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (191, 2006, 6.23600000000009);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (192, 2006, -0.3);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (193, 2006, 4.19972134550317);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (194, 2006, -5.20000000000002);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (195, 2006, 1.99999999999998);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (196, 2006, 11.56);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (197, 2006, 1.2);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (198, 2006, 1.87763084919117);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (199, 2006, 6.40000000000001);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (200, 2006, 5.04697172868775);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (201, 2006, 1.74897119341566);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (202, 2006, 6.00000000000001);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (203, 2006, 7.00056670661418);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (204, 2006, 6.20000000000001);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (205, 2006, 4.89999999999999);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (206, 2006, 7.90000000000002);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (207, 2006, 4.60144557407283);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (208, 2006, 11.4);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (209, 2006, 3.49999999999999);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (210, 2006, 8.50332923364012);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (211, 2006, 4.09999866310162);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (212, 2006, 5.19999999999998);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (213, 2006, 5.58429522284947);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (214, 2006, 5.29999999999999);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (215, 2006, 5);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (216, 2006, 1.99999999999998);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (217, 2006, 5.29999999999999);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (218, 2006, 8.60000000000003);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (219, 2006, 11.289);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (220, 2006, 2);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (221, 2006, 6.20000000000001);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (222, 2006, 2.00000000000002);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (223, 2006, 5.39999999999998);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (224, 2006, 5.58632982259746);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (225, 2006, 6.1920762525127);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (226, 2006, -3.43639214135419);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (229, 2006, 2.69975184635911);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (230, 2006, 2.71698261625168);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (231, 2006, 7.24838583508698);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (232, 2006, 5.21396636912861);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (233, 2006, 5.84792442893418);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (234, 2006, 7.7601984424895);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (235, 2006, 7.34081971641365);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (236, 2006, 7.44001220474333);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (237, 2006, 7.26257874557614);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (133, 2007, 17.4);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (134, 2007, 2.49204080998964);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (135, 2007, 6.81313547321938);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (136, 2007, 4.07630986817731);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (137, 2007, 4.25232863187013);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (138, 2007, 3.19527785515845);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (139, 2007, 2.81907589686525);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (140, 2007, -6.60000000000001);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (141, 2007, 2.17895825000003);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (142, 2007, -0.500000000000056);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (143, 2007, 7.20000000000003);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (144, 2007, 3);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (145, 2007, -3.13879352623835);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (146, 2007, 3);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (147, 2007, 3);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (148, 2007, 6.52200000000001);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (149, 2007, 5.69999999999997);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (150, 2007, 10.2597402597403);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (151, 2007, -3.49999481193253);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (152, 2007, 6.80000000000001);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (153, 2007, 7.30331332855751);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (154, 2007, 4.82963464840533);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (155, 2007, 6.59293103292393);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (156, 2007, 5.05580740358185);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (157, 2007, 3.38997755166868);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (158, 2007, 4.45242217551756);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (159, 2007, 5.50273399875183);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (160, 2007, 8.38389221892058);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (161, 2007, 5.36803438766977);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (162, 2007, 8.91136619373492);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (163, 2007, 4.36245529929309);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (164, 2007, 7.5);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (165, 2007, 6.09999999999999);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (1, 2007, 3.72036341400122);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (2, 2007, 4.40066198168647);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (3, 2007, 2.01424464474913);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (4, 2007, 2.71331940270976);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (5, 2007, 1.9474114147439);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (6, 2007, 5.22232889903118);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (7, 2007, 3.2939257566579);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (8, 2007, 4.28936555675827);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (9, 2007, 6.30000000000002);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (10, 2007, 1.94701955563399);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (11, 2007, 3.29999999999997);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (12, 2007, 1.57086441421677);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (13, 2007, 4.63692262829505);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (14, 2007, 7.79546629274332);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (15, 2007, 7.44874477462225);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (16, 2007, 1.6);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (17, 2007, 8.47462477828751);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (18, 2007, 4.65001449260587);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (19, 2007, 3.49999999999997);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (20, 2007, 6.26872246946775);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (21, 2007, 2.09999999999999);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (22, 2007, 6.3003724787406);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (23, 2007, 1.42926686788045);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (24, 2007, 3.15065741600495);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (25, 2007, 11.5430551362986);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (26, 2007, -1.38326870878787);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (27, 2007, 3.09999999999997);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (28, 2007, 0.499999999999989);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (29, 2007, 7.7);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (30, 2007, 5.50087451000001);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (31, 2007, 6.25332549594642);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (32, 2007, 8.64178476862434);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (33, 2007, 5.41173476139536);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (34, 2007, 6.96479202964895);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (35, 2007, 4.56438445765799);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (36, 2007, 4.75079437649537);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (37, 2007, 7.54586899106242);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (38, 2007, 2.49495316815498);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (39, 2007, 5.33078659489494);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (40, 2007, 6.76130456762818);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (41, 2007, 8.85673199639172);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (42, 2007, 5.3920704845815);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (43, 2007, 7.58165288852726);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (44, 2007, 8.46299828318173);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (45, 2007, 2.89990398440041);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (46, 2007, 2.84952262925782);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (47, 2007, 2.62432043654701);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (48, 2007, 3.03682023184029);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (49, 2007, 2.83098062968161);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (50, 2007, 2.59814807844319);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (51, 2007, 5.19073955030922);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (52, 2007, 1.98728167804914);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (53, 2007, 4.20207141674205);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (54, 2007, 2.25983903423035);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (55, 2007, 2.58458192327571);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (56, 2007, 4.03596415016692);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (57, 2007, 6.02506579351731);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (58, 2007, 1.46451397219327);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (59, 2007, 3.61289903127235);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (60, 2007, 1.87226600730275);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (61, 2007, 3.66409052642558);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (62, 2007, 2.69808215636114);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (63, 2007, 2.55916851251285);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (64, 2007, 6.21122855183607);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (65, 2007, 6.19661583846125);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (66, 2007, 4.36157235679255);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (67, 2007, 6.13550846794557);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (68, 2007, 6.33292120559716);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (69, 2007, 1.34379257453892);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (70, 2007, 9.97761135673862);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (71, 2007, 8.92471605353935);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (72, 2007, 4.23441321455491);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (73, 2007, 6.8034990822651);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (74, 2007, 6.20733380468255);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (75, 2007, 10.4231895039471);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (76, 2007, 6.76455407834506);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (77, 2007, 3.77831616564106);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (78, 2007, 3.30782932441731);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (79, 2007, 5.51191919742406);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (80, 2007, 3.17065995186283);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (81, 2007, 3.32597868442106);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (82, 2007, 6.73103556246455);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (83, 2007, 6.28053964058592);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (84, 2007, 12.1413653549109);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (85, 2007, 5.47141455062214);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (86, 2007, 5.89999999999999);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (87, 2007, 6.90489111426469);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (88, 2007, 8.49582987745867);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (89, 2007, 8.1);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (90, 2007, 7.72739882255031);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (91, 2007, 10.9649070008715);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (92, 2007, 13.4);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (93, 2007, 24.7);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (94, 2007, 8.20000000000001);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (95, 2007, 12.4298079289327);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (96, 2007, 8.93475952788756);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (97, 2007, 8.5);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (98, 2007, 3.04904295309629);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (99, 2007, 7.7999997378938);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (100, 2007, 11.5999999999999);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (101, 2007, 9.49999825533978);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (102, 2007, 5.74591773933115);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (103, 2007, 5.88211851605966);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (104, 2007, 8.65184812512831);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (105, 2007, 5.49261698923305);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (106, 2007, 9.25888201060106);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (107, 2007, 11.4);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (108, 2007, 6.36759694019282);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (109, 2007, 2.03348565095343);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (110, 2007, 4.97278991828096);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (111, 2007, 5.72260032636358);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (112, 2007, 22.4757144612255);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (113, 2007, 25.5731343283582);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (114, 2007, 9.9);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (115, 2007, 6.36018330368362);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (116, 2007, 6.27813457517561);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (117, 2007, 6.25599757571675);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (118, 2007, 7.18685413506277);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (119, 2007, 4.92624355085234);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (120, 2007, 8.48060104135673);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (121, 2007, 6.9615264825426);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (122, 2007, 0.600000000000001);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (123, 2007, 5.29999999999997);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (124, 2007, 10.3372500342041);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (125, 2007, 7.48883281697217);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (126, 2007, 7.76624570853766);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (127, 2007, 8.52891211546187);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (128, 2007, 6.42752684950316);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (129, 2007, 9.0266737495557);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (130, 2007, 6.38518223659124);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (131, 2007, 7.75776781045319);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (132, 2007, 12.5);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (166, 2007, 6.32870429227845);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (167, 2007, 5.23051796645362);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (168, 2007, 4.93718622029937);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (169, 2007, 4.01973767086881);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (170, 2007, 6.03710253379193);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (171, 2007, 4.92421611206679);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (172, 2007, 3.37694751172291);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (173, 2007, 7.2);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (174, 2007, 5.71970295465318);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (175, 2007, 2.2);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (176, 2007, 6.26568085437067);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (177, 2007, 5.52020961766106);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (178, 2007, 6.58565814105414);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (179, 2007, 5.14041674041199);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (180, 2007, 7.35252309918168);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (181, 2007, 21.1);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (182, 2007, 4.6);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (183, 2007, 6.16646454983325);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (184, 2007, 3.6);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (185, 2007, 3.69999999999999);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (186, 2007, 3.29999999999999);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (187, 2007, 7.76600000000001);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (188, 2007, 3.6);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (189, 2007, 0.180000000000002);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (190, 2007, -2.91262135922331);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (191, 2007, -1.57999999999999);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (192, 2007, 1.6);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (193, 2007, 6.00000000000001);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (194, 2007, 10);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (195, 2007, 1.29999999999999);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (196, 2007, 11.43);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (197, 2007, 5.60000000000001);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (198, 2007, 6.29999999999999);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (199, 2007, 6.29999999999999);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (200, 2007, 1.50975547287568);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (201, 2007, 2.69999999999999);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (202, 2007, 7.02099999999999);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (203, 2007, 4.89541579693338);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (204, 2007, 9.5);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (205, 2007, 6.31643733943199);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (206, 2007, 7.40290363814049);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (207, 2007, 2.47869389337487);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (208, 2007, 0.874800307120216);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (209, 2007, 4.196);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (210, 2007, 6.99999999958603);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (211, 2007, 4.40670510224641);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (212, 2007, 3.29999999999999);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (213, 2007, 6.44975939093586);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (214, 2007, 7.9);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (215, 2007, 5.99999999999998);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (216, 2007, 4.75000000000001);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (217, 2007, 5.26951460113945);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (218, 2007, 6.40000000000001);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (219, 2007, 10.163);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (220, 2007, 2.36768746808254);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (221, 2007, 7.148);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (222, 2007, 1.89999999999999);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (223, 2007, 8.588);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (224, 2007, 6.257);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (225, 2007, 5.80336813224356);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (226, 2007, -6.09203440965183);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (229, 2007, 2.33727599805305);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (230, 2007, 2.58647761117874);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (231, 2007, 7.06109992591348);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (232, 2007, 5.28089467903465);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (233, 2007, 4.16446198555347);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (234, 2007, 7.60869051844737);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (235, 2007, 7.47889844258125);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (236, 2007, 7.62182055330645);
insert into gdp_growth_by_year
   (ENTITY_ID, GDP_YEAR, GDP_VALUE)
 values
   (237, 2007, 7.12529827229105);
commit;
